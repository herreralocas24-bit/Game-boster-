# FPS TRIGER — Gaming Booster (MVP)

Aplicación Android en Python/Kivy con dashboard, selector de juegos, perfiles gráficos informativos,
panel de sensibilidad y monitor de rendimiento con modo demostración.

## Estado real de las funciones
- La interfaz y navegación son funcionales.
- El monitor incluido muestra una demo claramente etiquetada. Android no ofrece una API pública
  universal para leer los FPS de cualquier juego desde otra app. Una medición real requiere una
  integración específica por fabricante/juego o un servicio del sistema compatible.
- Shizuku no se puede activar silenciosamente: instala Shizuku, inicia su servicio y autoriza FPS TRIGER.
  Este MVP incluye el panel de estado e instrucciones, pero NO declara una conexión Shizuku verificada
  ni ejecuta comandos privilegiados. Para integrar la API oficial hay que añadir el módulo Android
  Kotlin descrito abajo a un proyecto Gradle/`python-for-android` personalizado.
- La sensibilidad táctil interna de cada juego no es una preferencia Android global. Los controles
  guardan perfiles locales; no prometen cambiar la sensibilidad del juego.
- Los perfiles de textura son recomendaciones visuales. No editan archivos privados del juego ni
  evaden protecciones antitrampas.

## Estructura
```
fps_triger/
  main.py
  buildozer.spec
  requirements.txt
  README.md
  shizuku_bridge/
    README.md
    AndroidManifest.xml
    FpsTrigerShizukuBridge.kt
```

## Ejecutar como aplicación de escritorio
Python 3.10+:
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python main.py
```

## Compilar APK (Linux o macOS; Windows mediante WSL)
Instala Java 17 y dependencias de Buildozer según la documentación oficial.
```bash
pip install buildozer
buildozer android debug
```
APK: `bin/` (la primera compilación descarga SDK/NDK y puede tardar).

La documentación oficial recomienda Buildozer para empaquetar Kivy en Android:
https://kivy.org/doc/stable/guide/packaging-android.html

## Integración oficial de Shizuku
Consulta `shizuku_bridge/README.md` y la API oficial:
https://github.com/RikkaApps/Shizuku-API

No copies comandos `settings put` a ciegas: el resultado depende del fabricante, Android y del
permiso concreto. Prueba primero en un dispositivo secundario y permite que el usuario confirme
cada operación.


## Compilar APK usando solamente Android (GitHub Actions)

Este proyecto incluye `.github/workflows/build-apk.yml` para compilar en la nube:
1. En Chrome, entra en https://github.com y crea una cuenta o inicia sesión.
2. Crea un repositorio nuevo y sube el contenido de esta carpeta (incluida la carpeta oculta `.github`).
3. Abre la pestaña **Actions**, selecciona **Build FPS TRIGER APK** y pulsa **Run workflow**.
4. Cuando termine, abre la ejecución y descarga el artefacto **FPS-TRIGER-debug-APK**.
5. Extrae el ZIP descargado y toca el archivo `.apk` para instalarlo. Si Android lo solicita, permite instalar apps desde Chrome o desde tu administrador de archivos.

La compilación en la nube puede fallar si Buildozer o alguna dependencia cambia; revisa el registro de Actions si ocurre. Este flujo genera un APK de depuración, no uno publicado en Play Store. Las limitaciones funcionales indicadas arriba siguen aplicando: FPS de demostración, perfiles locales y puente Shizuku de referencia, no integración universal con todos los juegos.

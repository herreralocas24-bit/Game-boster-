\
import random
from kivy.app import App
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.slider import Slider
from kivy.uix.spinner import Spinner
from kivy.uix.progressbar import ProgressBar
from kivy.uix.scrollview import ScrollView
from kivy.graphics import Color, RoundedRectangle

BG = (0.035, 0.055, 0.10, 1)
PANEL = (0.075, 0.12, 0.21, 1)
CYAN = (0.25, 0.82, 1, 1)
WHITE = (0.91, 0.96, 1, 1)
MUTED = (0.60, 0.72, 0.84, 1)

class Card(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation="vertical", padding=dp(14), spacing=dp(8),
                         size_hint_y=None, **kwargs)
        self.bind(minimum_height=self.setter("height"))
        with self.canvas.before:
            Color(*PANEL)
            self.bg = RoundedRectangle(radius=[dp(18)])
        self.bind(pos=self._sync, size=self._sync)
    def _sync(self, *_):
        self.bg.pos, self.bg.size = self.pos, self.size

class FPSApp(App):
    def build(self):
        Window.clearcolor = BG
        self.fps = 60
        self.demo_on = True
        self.current_page = "Inicio"
        self.games = ["Seleccionar juego", "Free Fire", "PUBG Mobile", "Call of Duty Mobile", "Minecraft"]
        self.root_box = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(10))
        self.header = Label(text="[b]FPS TRIGER[/b]\n[color=55D7FF]GAMING BOOSTER  •  v1.0[/color]",
                            markup=True, size_hint_y=None, height=dp(72), font_size="22sp")
        self.root_box.add_widget(self.header)
        self.nav = GridLayout(cols=4, size_hint_y=None, height=dp(46), spacing=dp(5))
        for name in ("Inicio", "FPS", "Ajustes", "Shizuku"):
            b = Button(text=name, background_normal="", background_color=(0.10,0.24,0.38,1),
                       color=WHITE, font_size="12sp")
            b.bind(on_release=lambda _b, n=name: self.show_page(n))
            self.nav.add_widget(b)
        self.root_box.add_widget(self.nav)
        self.scroll = ScrollView()
        self.content = BoxLayout(orientation="vertical", spacing=dp(10), size_hint_y=None)
        self.content.bind(minimum_height=self.content.setter("height"))
        self.scroll.add_widget(self.content)
        self.root_box.add_widget(self.scroll)
        self.show_page("Inicio")
        Clock.schedule_interval(self.tick, 1)
        return self.root_box

    def label(self, text, size=14, color=WHITE, height=None):
        return Label(text=text, markup=True, color=color, font_size=f"{size}sp",
                     size_hint_y=None, height=dp(height or (42 if "\n" not in text else 58)),
                     halign="left", valign="middle")

    def card(self):
        c = Card()
        self.content.add_widget(c)
        return c

    def action_button(self, text, callback):
        b = Button(text=text, size_hint_y=None, height=dp(44),
                   background_normal="", background_color=(0.08,0.48,0.68,1),
                   color=WHITE)
        b.bind(on_release=callback)
        return b

    def show_page(self, page):
        self.current_page = page
        self.content.clear_widgets()
        if page == "Inicio":
            c = self.card()
            c.add_widget(self.label("[b]PANEL DE RENDIMIENTO[/b]", 17, CYAN))
            c.add_widget(self.label("Estado: interfaz lista  •  Modo seguro", 13, MUTED))
            c.add_widget(self.label("[b]60 FPS[/b]\nDemo visual — no es lectura real del juego", 24, CYAN, 76))
            c.add_widget(self.action_button("Abrir monitor FPS", lambda *_: self.show_page("FPS")))
            c = self.card()
            c.add_widget(self.label("[b]SELECCIONAR JUEGO[/b]", 16, CYAN))
            self.game_spinner = Spinner(text=self.games[0], values=self.games[1:],
                                        size_hint_y=None, height=dp(46))
            c.add_widget(self.game_spinner)
            c.add_widget(self.label("El selector organiza perfiles; no modifica el juego.", 12, MUTED))
            c = self.card()
            c.add_widget(self.label("[b]MÓDULOS[/b]", 16, CYAN))
            for t in ("Monitor de rendimiento", "Perfiles gráficos", "Perfiles de sensibilidad", "Estado Shizuku"):
                c.add_widget(self.label("• " + t, 14, WHITE, 30))
        elif page == "FPS":
            c = self.card()
            c.add_widget(self.label("[b]FPS MONITOR[/b]", 18, CYAN))
            self.fps_label = self.label("[b]60 FPS[/b]", 36, CYAN, 70)
            c.add_widget(self.fps_label)
            c.add_widget(self.label("DEMO: valor ilustrativo. No representa FPS reales.", 12, MUTED))
            self.fps_bar = ProgressBar(max=120, value=60, size_hint_y=None, height=dp(14))
            c.add_widget(self.fps_bar)
            c.add_widget(self.label("Para FPS reales se necesita una fuente del fabricante, juego o sistema.", 12, MUTED, 55))
            c.add_widget(self.action_button("Pausar / reanudar demo", self.toggle_demo))
        elif page == "Ajustes":
            c = self.card()
            c.add_widget(self.label("[b]PERFIL DE SENSIBILIDAD[/b]", 17, CYAN))
            c.add_widget(self.label("Sensibilidad preferida: perfil local (0–100)", 13, MUTED))
            self.sens = Slider(min=0, max=100, value=50)
            c.add_widget(self.sens)
            self.sens_value = self.label("Valor guardado en pantalla: 50", 14)
            c.add_widget(self.sens_value)
            self.sens.bind(value=lambda _, v: setattr(self.sens_value, "text", f"Valor del perfil: {int(v)}"))
            c.add_widget(self.label("Este perfil no altera por sí solo la sensibilidad interna de cada juego.", 12, MUTED, 55))
            c = self.card()
            c.add_widget(self.label("[b]TEXTURE LAB — PERFILES[/b]", 17, CYAN))
            c.add_widget(self.label("Elige un objetivo gráfico recomendado:", 13, MUTED))
            self.texture = Spinner(text="Equilibrado", values=("Bajo consumo", "Equilibrado", "Calidad alta"),
                                   size_hint_y=None, height=dp(46))
            c.add_widget(self.texture)
            c.add_widget(self.label("Los perfiles son recomendaciones; no reemplazan archivos ni fuerzan ajustes del juego.", 12, MUTED, 60))
        elif page == "Shizuku":
            c = self.card()
            c.add_widget(self.label("[b]SHIZUKU BRIDGE[/b]", 18, CYAN))
            c.add_widget(self.label("Estado: no verificado desde este MVP", 14, MUTED))
            c.add_widget(self.label("1. Instala Shizuku desde su fuente oficial.\n2. Inicia el servicio mediante depuración inalámbrica o root.\n3. Autoriza FPS TRIGER en Shizuku.\n4. Reinicia la app y verifica la integración nativa.", 13, WHITE, 130))
            c.add_widget(self.action_button("Abrir guía de integración", lambda *_: self.show_page("Guía")))
            c.add_widget(self.label("No se ejecutan comandos privilegiados en segundo plano.", 12, MUTED, 50))
        else:
            c = self.card()
            c.add_widget(self.label("[b]INTEGRACIÓN PARA DESARROLLADORES[/b]", 17, CYAN))
            c.add_widget(self.label("El proyecto incluye un esqueleto Kotlin y manifiesto en shizuku_bridge/. Para completar el enlace Python↔Kotlin hay que compilarlo dentro de un módulo Android Gradle o receta personalizada de python-for-android.", 13, WHITE, 150))
            c.add_widget(self.label("API oficial: github.com/RikkaApps/Shizuku-API", 12, MUTED, 50))

    def toggle_demo(self, *_):
        self.demo_on = not self.demo_on
    def tick(self, _dt):
        if self.demo_on:
            self.fps = random.randint(55, 63)
            if self.current_page == "FPS" and hasattr(self, "fps_label"):
                self.fps_label.text = f"[b]{self.fps} FPS[/b]"
                self.fps_bar.value = self.fps

if __name__ == "__main__":
    FPSApp().run()

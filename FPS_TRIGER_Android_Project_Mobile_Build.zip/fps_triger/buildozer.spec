[app]
title = FPS TRIGER
package.name = fpstriger
package.domain = com.fpstriger
source.dir = .
source.include_exts = py,kv,png,jpg,atlas,md
version = 1.0.0
requirements = python3,kivy==2.3.1
orientation = portrait
fullscreen = 0

# Ajusta estos valores a la versión del toolchain instalada.
android.api = 35
android.minapi = 23
android.archs = arm64-v8a
android.permissions = INTERNET
android.allow_backup = False

[buildozer]
log_level = 2
warn_on_root = 1

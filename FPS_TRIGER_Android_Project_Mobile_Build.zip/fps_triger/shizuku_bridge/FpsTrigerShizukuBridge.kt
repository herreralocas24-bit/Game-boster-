package com.fpstriger.bridge

import rikka.shizuku.Shizuku

/** Fachada de referencia; requiere integrarse en un módulo Android Gradle. */
class FpsTrigerShizukuBridge {
    fun isBinderAlive(): Boolean = Shizuku.pingBinder()

    fun hasPermission(): Boolean =
        Shizuku.pingBinder() &&
        Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED

    fun requestPermission(requestCode: Int) {
        if (!Shizuku.pingBinder()) throw IllegalStateException("Shizuku no está iniciado")
        if (!hasPermission()) Shizuku.requestPermission(requestCode)
    }
}

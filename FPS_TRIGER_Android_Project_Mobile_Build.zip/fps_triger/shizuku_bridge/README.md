# Shizuku Android bridge — integración nativa pendiente

El MVP Kivy no enlaza todavía esta clase. Para integrarla, crear un módulo Android Gradle,
añadir la API oficial de Shizuku, registrar el callback de permisos y exponer la fachada
a Python mediante PyJNIus. No marques Shizuku como conectado hasta comprobar
`Shizuku.pingBinder()` y el permiso del paquete.

Dependencias Gradle (elige una versión publicada compatible):
```gradle
implementation("dev.rikka.shizuku:api:<version>")
implementation("dev.rikka.shizuku:provider:<version>")
```
Documentación: https://github.com/RikkaApps/Shizuku-API

Pasos: crear módulo Gradle; declarar provider/metadata requeridos por la versión;
implementar `Shizuku.requestPermission`; registrar `OnRequestPermissionResultListener`;
exponer estado mediante PyJNIus; verificar binder, permiso y UID; pedir confirmación
antes de cada operación. Los permisos ADB/root son limitados y dependen de Android/OEM.
